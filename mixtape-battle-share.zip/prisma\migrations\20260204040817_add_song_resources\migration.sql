-- AlterTable
ALTER TABLE "Song" ADD COLUMN "album" TEXT;
ALTER TABLE "Song" ADD COLUMN "lyricsUrl" TEXT;
ALTER TABLE "Song" ADD COLUMN "releaseDate" INTEGER;
ALTER TABLE "Song" ADD COLUMN "songsterrBassUrl" TEXT;
ALTER TABLE "Song" ADD COLUMN "songsterrGuitarUrl" TEXT;
ALTER TABLE "Song" ADD COLUMN "youtubeUrl" TEXT;
