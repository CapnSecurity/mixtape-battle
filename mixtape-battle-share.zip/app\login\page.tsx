"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { FaSignInAlt, FaUserPlus, FaEnvelope, FaLock } from "react-icons/fa";
import AuthShell from "@/src/components/AuthShell";
import Button from "@/src/components/ui/Button";
import Input from "@/src/components/ui/Input";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [mode, setMode] = useState<'signin'|'signup'>('signin');

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      if (mode === 'signin') {
        // Try password sign in first
        const result = await signIn("credentials", { email, password, redirect: false });
        if (!result || result?.error) {
          setError("Invalid email or password. Try again or use magic link.");
        } else {
          router.push("/battle");
        }
      } else {
        if (!password || password.length < 8) {
          setError("Please use a password with at least 8 characters.");
          return;
        }
        const res = await fetch("/api/auth/signup", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, password }),
        });
        if (res.status === 409) {
          setError("An account with that email already exists. Please sign in.");
          setMode("signin");
          return;
        }
        if (!res.ok) {
          const data = await res.json().catch(() => ({}));
          setError(data?.error || "Sign up failed. Please try again.");
          return;
        }
        const result = await signIn("credentials", { email, password, redirect: false });
        if (!result || result?.error) {
          setError("Sign up succeeded, but sign in failed. Please sign in.");
          setMode("signin");
          return;
        }
        router.push("/battle");
      }
    } catch (err) {
      setError("An unexpected error occurred.");
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setSent(false);
    setEmail("");
    setError("");
  };

  return (
    <AuthShell>
      <div className="w-full max-w-xl">
        {/* Logo */}
        <div className="text-center mb-10">
          <div className="text-6xl mb-3">🎵</div>
          <h1 className="text-5xl font-bold text-[var(--text)] mb-2">Mixtape</h1>
          <p className="text-[var(--muted)] text-lg">
            Band Music Management Platform
          </p>
        </div>

        {/* Card */}
        <div className="p-10 rounded-3xl border border-[var(--ring)]/20 bg-[var(--surface)]/85 shadow-[var(--shadow)] backdrop-blur">
          {!sent ? (
            <>
              <h2 className="text-3xl font-bold text-[var(--text)] mb-3 flex items-center gap-2">
                {mode === 'signin' ? <FaSignInAlt className="inline text-[var(--gold)]" /> : <FaUserPlus className="inline text-[var(--pink)]" />}
                {mode === 'signin' ? 'Sign In' : 'Sign Up'}
              </h2>
              <p className="text-[var(--muted)] mb-8 text-base leading-relaxed">
                {mode === 'signin'
                  ? 'Sign in with your email and password below, or use a magic link if you prefer passwordless login.'
                  : 'Sign up with your email and password below, or use a magic link for passwordless signup.'}
              </p>

              <form onSubmit={submit} className="space-y-6">
                <div>
                  <label htmlFor="email" className="block text-sm font-semibold text-[var(--text)] mb-2 flex items-center gap-2">
                    <FaEnvelope className="inline text-[var(--gold)]" /> Email Address
                  </label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="password" className="block text-sm font-semibold text-[var(--text)] mb-2 flex items-center gap-2">
                    <FaLock className="inline text-[var(--gold)]" /> Password
                  </label>
                  <Input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Password (min 8 chars)"
                    required={mode === 'signup'}
                    minLength={8}
                  />
                </div>

                {error && (
                  <div className="p-4 bg-[var(--surface2)] border border-[var(--pink)]/60 text-[var(--pink)] rounded-xl text-sm font-medium">
                    {error}
                  </div>
                )}

                <Button
                  type="submit"
                  size="lg"
                  disabled={loading}
                  className="w-full text-base"
                >
                  {loading ? (
                    <span>
                      {mode === 'signin' ? 'Signing In...' : 'Signing Up...'}
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      {mode === 'signin' ? <FaSignInAlt /> : <FaUserPlus />}
                      {mode === 'signin' ? 'Sign In' : 'Sign Up'}
                    </span>
                  )}
                </Button>
              </form>

              <div className="flex flex-col sm:flex-row justify-between gap-3 mt-8">
                <Button
                  variant="ghost"
                  type="button"
                  onClick={() => setMode(mode === 'signin' ? 'signup' : 'signin')}
                >
                  {mode === 'signin' ? 'Need an account? Sign Up' : 'Already have an account? Sign In'}
                </Button>
                <Button
                  variant="ghost"
                  type="button"
                  onClick={async () => {
                    setLoading(true);
                    setError("");
                    try {
                      const result = await signIn("email", { email, redirect: false });
                      if (result?.error) {
                        setError("Failed to send magic link. Please try again.");
                      } else {
                        setSent(true);
                      }
                    } catch (err) {
                      setError("An unexpected error occurred.");
                    } finally {
                      setLoading(false);
                    }
                  }}
                >
                  <FaEnvelope className="inline" /> Use Magic Link
                </Button>
              </div>
              <div className="mt-8 text-[var(--muted)] text-xs text-center">
                <span className="block mb-1">• Passwords are securely encrypted and never shared.</span>
                <span className="block">• Magic link sign-in is instant in development (see MailHog below).</span>
              </div>
            </>
          ) : (
            <>
              <div className="text-center">
                <div className="text-6xl mb-4">📧</div>
                <h2 className="text-3xl font-bold text-[var(--text)] mb-2">
                  Check Your Email
                </h2>
                <p className="text-[var(--muted)] mb-6">
                  We've sent a magic link to{' '}
                  <strong className="text-[var(--text)]">{email}</strong>. Click it to
                  sign in.
                </p>

                <div className="bg-[var(--surface2)] border border-[var(--ring)]/30 rounded-xl p-5 mb-8 text-left">
                  <p className="text-[var(--muted)] text-sm">
                    <strong>⚙️ Development Mode:</strong> Check MailHog at{' '}
                    <a
                      href="http://localhost:8025"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="underline font-semibold hover:text-[var(--text)] transition"
                    >
                      localhost:8025
                    </a>
                  </p>
                </div>

                <Button type="button" variant="surface" onClick={handleReset} className="w-full">
                  Try Different Email
                </Button>
              </div>
            </>
            )}
          </div>

          {/* Footer */}
        <div className="mt-8 text-center text-[var(--muted)] text-sm">
          <Link href="/" className="hover:text-[var(--text)] transition font-medium">
            ← Back to Home
          </Link>
        </div>
      </div>
    </AuthShell>
  );
}
