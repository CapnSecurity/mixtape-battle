import Link from "next/link";
import { prisma } from "../../../lib/prisma";
import { songsterr, ultimateGuitar, youtube, lyrics } from "../../../lib/links";
import Button from "@/src/components/ui/Button";

type Params = Promise<{ id: string }>;

export default async function SongPage({ params }: { params: Params }) {
  const { id } = await params;
  const songId = Number(id);
  const song = await prisma.song.findUnique({ where: { id: songId } });
  if (!song)
    return (
      <div className="min-h-screen flex items-center justify-center px-4 bg-[var(--bg)] text-[var(--text)]">
        <div className="bg-[var(--surface)] rounded-2xl shadow-[var(--shadow)] p-8 text-center max-w-md border border-[var(--ring)]/20">
          <div className="text-5xl mb-4">🎵</div>
          <h1 className="text-3xl font-bold text-[var(--text)] mb-4">
            Song Not Found
          </h1>
          <p className="text-[var(--muted)] mb-6">
            We couldn't find this song. Please go back and try again.
          </p>
          <Button asChild>
            <Link href="/songs/browser">Back to Songs</Link>
          </Button>
        </div>
      </div>
    );

  return (
    <div className="min-h-screen py-12 px-4 bg-[var(--bg)] text-[var(--text)]">
      <div className="max-w-2xl mx-auto">
        {/* Back Button */}
        <Link
          href="/songs/browser"
          className="inline-block text-[var(--muted)] hover:text-[var(--text)] transition mb-8"
        >
          ← Back to Songs
        </Link>

        {/* Song Card */}
        <div className="bg-[linear-gradient(135deg,var(--gold),var(--pink))] rounded-2xl shadow-[var(--shadow)] p-8 mb-8">
          <div className="text-7xl mb-6 text-center">🎶</div>
          <h1 className="text-4xl font-bold text-[var(--bg)] mb-2 text-center">
            {song.title}
          </h1>
          <p className="text-xl text-[var(--bg)]/80 text-center mb-6">
            {song.artist}
          </p>

          <div className="bg-[var(--bg)]/20 rounded-xl p-6 text-center">
            <div className="text-sm text-[var(--bg)]/80 mb-2">Battle Score</div>
            <div className="text-5xl font-bold text-[var(--bg)]">
              {Math.round(song.elo)}
            </div>
          </div>
        </div>

        {/* Resource Links */}
        <div className="bg-[var(--surface)] rounded-2xl shadow-[var(--shadow)] p-8 border border-[var(--ring)]/20">
          <h2 className="text-2xl font-bold text-[var(--text)] mb-6">
            Learn This Song
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <a
              href={songsterr(song.artist, song.title)}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-3 p-4 border border-[var(--ring)]/20 rounded-xl hover:bg-[var(--surface2)] transition"
            >
              <span className="text-2xl">🎸</span>
              <div>
                <div className="font-bold text-[var(--text)]">Songsterr</div>
                <div className="text-sm text-[var(--muted)]">Interactive tabs</div>
              </div>
            </a>

            <a
              href={ultimateGuitar(song.artist, song.title)}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-3 p-4 border border-[var(--ring)]/20 rounded-xl hover:bg-[var(--surface2)] transition"
            >
              <span className="text-2xl">🎼</span>
              <div>
                <div className="font-bold text-[var(--text)]">Ultimate Guitar</div>
                <div className="text-sm text-[var(--muted)]">Tabs & chords</div>
              </div>
            </a>

            <a
              href={lyrics(song.artist, song.title)}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-3 p-4 border border-[var(--ring)]/20 rounded-xl hover:bg-[var(--surface2)] transition"
            >
              <span className="text-2xl">📝</span>
              <div>
                <div className="font-bold text-[var(--text)]">Lyrics</div>
                <div className="text-sm text-[var(--muted)]">Song lyrics & meanings</div>
              </div>
            </a>

            <a
              href={youtube(song.artist, song.title)}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-3 p-4 border border-[var(--ring)]/20 rounded-xl hover:bg-[var(--surface2)] transition"
            >
              <span className="text-2xl">▶️</span>
              <div>
                <div className="font-bold text-[var(--text)]">YouTube</div>
                <div className="text-sm text-[var(--muted)]">Watch performances</div>
              </div>
            </a>
          </div>
        </div>

        {/* Battle Button */}
        <div className="mt-8 text-center">
          <Button asChild>
            <Link href="/battle">Battle This Song ⚔️</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
